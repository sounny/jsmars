package com.bbn.openmap.image.wms;

public interface LayerFeatureInfoResponse {

    public void output(String contentType, StringBuffer out);
}
