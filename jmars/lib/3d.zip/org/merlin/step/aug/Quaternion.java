/**
 * Quaternion.java 1.00 98/07/14 Merlin Hughes
 *
 * Copyright (c) 1998 Merlin Hughes. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * for non-commercial purposes and without fee is hereby granted
 * provided that this copyright notice appears in all copies.
 *
 * http://merlin.org/                          merlin@merlin.org
 */

package org.merlin.step.aug;

public class Quaternion {
  private float w, x, y, z;
  private Quaternion inverse;

  public Quaternion (float w, float x, float y, float z) {
    this.w = w;
    this.x = x;
    this.y = y;
    this.z = z;
    this.inverse = null;
  }

  public Quaternion inverse () {
    float scale = 1.0f / (x * x + y * y + z * z + w * w);
    return new Quaternion (w * scale, - x * scale, - y * scale, - z * scale);
  }

  public Quaternion multiply (Quaternion q) {
    float qx = q.x, qy = q.y, qz = q.z, qw = q.w;
    float rw = w * qw - x * qx - y * qy - z * qz;
    float rx = w * qx + x * qw + y * qz - z * qy;
    float ry = w * qy + y * qw + z * qx - x * qz;
    float rz = w * qz + z * qw + x * qy - y * qx;
    return new Quaternion (rw, rx, ry, rz);
  }

  public Triple rotate (Triple t) {
    if (inverse == null)
      inverse = inverse ();

    float iw = inverse.w, ix = inverse.x, iy = inverse.y, iz = inverse.z;
    float tx = t.x, ty = t.y, tz = t.z;

    float aw = - x * tx - y * ty - z * tz;
    float ax = w * tx + y * tz - z * ty;
    float ay = w * ty + z * tx - x * tz;
    float az = w * tz + x * ty - y * tx;

    float bx = aw * ix + ax * iw + ay * iz - az * iy;
    float by = aw * iy + ay * iw + az * ix - ax * iz;
    float bz = aw * iz + az * iw + ax * iy - ay * ix;

    return new Triple (bx, by, bz);
  }

  public static Quaternion newRotation (float r, float x, float y, float z) {
    float len = (float)Math.sqrt (x * x + y * y + z * z);
    float sin = (float)Math.sin (r / 2.0);
    float cos = (float)Math.cos (r / 2.0);
    float tmp = sin / len;
    return new Quaternion (cos, x * tmp, y * tmp, z * tmp);
  }
}
