/**
 * Triple.java 1.00 98/07/14 Merlin Hughes
 *
 * Copyright (c) 1998 Merlin Hughes. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * for non-commercial purposes and without fee is hereby granted
 * provided that this copyright notice appears in all copies.
 *
 * http://merlin.org/                          merlin@merlin.org
 */

package org.merlin.step.aug;

public class Triple {
  public float x, y, z;

  public Triple (float x, float y, float z) {
    this.x = x;
    this.y = y;
    this.z = z;
  }
  
  public void setTriple (float x, float y, float z) {
    this.x = x;
    this.y = y;
    this.z = z;
  }
  
  public Triple add (Triple t) {
    return new Triple (x + t.x, y + t.y, z + t.z);
  }
  
  public Triple subtract (Triple t) {
    return new Triple (x - t.x, y - t.y, z - t.z);
  }
  
  public Triple cross (Triple t) {
    return new Triple (y * t.z - z * t.y, z * t.x - x * t.z,
      x * t.y - y * t.x);
  }

  public Triple scale (float scale) {
    return new Triple (x * scale, y * scale, z * scale);
  }
  
  public Triple addTo (Triple t) {
    x += t.x;
	 y += t.y;
	 z += t.z;
	 return(this);
  }
  
  public Triple subtractFrom (Triple t) {
    x -= t.x;
	 y -= t.y;
	 z -= t.z;
	 return(this);
  }

  public Triple scaleOn (float scale) {
    x *= scale;
	 y *= scale;
	 z *= scale;
	 return(this);
  }
  
  public float dot (Triple t) {
    return x * t.x + y * t.y + z * t.z;
  }
  
  public float length2 () {
    return dot (this);
  }
  
  public Triple normalise () {
    return scale (1.0f / (float)Math.sqrt (length2 ()));
  }

  public Triple normaliseSelf () {
    return (this.scaleOn (1.0f / (float)Math.sqrt (length2 ())));
  }
}
