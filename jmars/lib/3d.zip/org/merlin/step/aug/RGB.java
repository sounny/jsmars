/**
 * RGB.java 1.00 98/07/14 Merlin Hughes
 *
 * Copyright (c) 1998 Merlin Hughes. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * for non-commercial purposes and without fee is hereby granted
 * provided that this copyright notice appears in all copies.
 *
 * http://merlin.org/                          merlin@merlin.org
 */

package org.merlin.step.aug;

public class RGB {
  private float r, g, b;

  public RGB (float r, float g, float b) {
    this.r = r;
    this.g = g;
    this.b = b;
  }

  public void setRGB (float r, float g, float b) {
    this.r = r;
    this.g = g;
    this.b = b;
  }

  public RGB add (RGB rgb) {
    return new RGB (r + rgb.r, g + rgb.g, b + rgb.b);
  }

  public RGB subtract (RGB rgb) {
    return new RGB (r - rgb.r, g - rgb.g, b - rgb.b);
  }

  public RGB scale (float scale) {
    return new RGB (r * scale, g * scale, b * scale);
  }

  public RGB addTo (RGB rgb) {
    this.r += rgb.r; 
	 this.g += rgb.g;
	 this.b += rgb.b;
	 return(this);
  }

  public RGB subtractFrom (RGB rgb) {
    this.r -= rgb.r; 
	 this.g -= rgb.g;
	 this.b -= rgb.b;
	 return(this);
  }

  public RGB scaleOn (float scale) {
    this.r *= scale; 
	 this.g *= scale;
	 this.b *= scale;
	 return(this);
  }

  private int toInt (float value) {
    int v = (int) (value * 255.5);
    return (v < 0) ? 0 : (v > 255) ? 255 : v;
  }

  public int toRGB () {
    return (0xff << 24) | (toInt (r) << 16) |
      (toInt (g) << 8) | toInt (b);
  }
}
