/**
 * Vertex.java 1.00 98/07/14 Merlin Hughes
 *
 * Copyright (c) 1998 Merlin Hughes. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * for non-commercial purposes and without fee is hereby granted
 * provided that this copyright notice appears in all copies.
 *
 * http://merlin.org/                          merlin@merlin.org
 */

package org.merlin.step.aug;

public class Vertex {
  public XY xy;
  public float z;
  public RGB rgb;
  public Vertex (XY xy, float z, RGB rgb) {
    this.xy = xy;
    this.z = z;
    this.rgb = rgb;
  }
}
