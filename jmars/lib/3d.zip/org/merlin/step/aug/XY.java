/**
 * XY.java 1.00 98/07/14 Merlin Hughes
 *
 * Copyright (c) 1998 Merlin Hughes. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * for non-commercial purposes and without fee is hereby granted
 * provided that this copyright notice appears in all copies.
 *
 * http://merlin.org/                          merlin@merlin.org
 */

package org.merlin.step.aug;

public class XY {
  public int x, y;
  public XY (int x, int y) {
    this.x = x;
    this.y = y;
  }


  public void setXY(int x, int y)
	{
		this.x = x;
		this.y = y;
	}

}
