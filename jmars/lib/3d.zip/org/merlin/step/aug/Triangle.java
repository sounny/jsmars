/**
 * Triangle.java 1.00 98/07/14 Merlin Hughes
 *
 * Copyright (c) 1998 Merlin Hughes. All Rights Reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * for non-commercial purposes and without fee is hereby granted
 * provided that this copyright notice appears in all copies.
 *
 * http://merlin.org/                          merlin@merlin.org
 */

package org.merlin.step.aug;

import java.awt.*;

public class Triangle {
  public int[] i = new int[3];
  public int[] j = new int[3];
  public RGB[] rgb = new RGB[3];
  public Triple n;
  public Color color;

  public Triangle (int i0, int j0, int i1, int j1, int i2, int j2) {
    i[0] = i0;
    i[1] = i1;
    i[2] = i2;
    j[0] = j0;
    j[1] = j1;
    j[2] = j2;
  }
}
